import React, { createContext, useContext, useState } from 'react';

const DonationContext = createContext();

export function useDonation() {
  const context = useContext(DonationContext);
  if (!context) {
    throw new Error('useDonation must be used within a DonationProvider');
  }
  return context;
}

export function DonationProvider({ children }) {
  const [isOpen, setIsOpen] = useState(false);

  const openDonation = () => setIsOpen(true);
  const closeDonation = () => setIsOpen(false);

  return (
    <DonationContext.Provider value={{ isOpen, openDonation, closeDonation }}>
      {children}
    </DonationContext.Provider>
  );
}