import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';
import { useDonation } from '../contexts/DonationContext';
import { showToast } from '../utils/helpers';

const { FiX, FiCopy, FiHeart } = FiIcons;

export default function DonationModal() {
  const { isOpen, closeDonation } = useDonation();

  const donationDetails = {
    airtel: '0750463854',
    bank: 'Lead Bank',
    account: '216858671770',
    routing: '101019644'
  };

  const copyToClipboard = () => {
    const text = `💖 MyLinkMart Donation Details:

📱 Airtel Money: ${donationDetails.airtel}

🏦 Bank: ${donationDetails.bank}
Account Number: ${donationDetails.account}
Routing Number: ${donationDetails.routing}

Thank you for supporting this dream! ☕`;

    navigator.clipboard.writeText(text).then(() => {
      showToast('Donation details copied to clipboard! 📋', 'success');
    }).catch(() => {
      showToast('Failed to copy. Please copy manually.', 'error');
    });
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={closeDonation}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 relative"
          >
            <button
              onClick={closeDonation}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors"
            >
              <SafeIcon icon={FiX} className="text-xl" />
            </button>

            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-gradient-to-r from-red-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <SafeIcon icon={FiHeart} className="text-white text-2xl" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">
                💖 Support MyLinkMart Project
              </h2>
              <p className="text-gray-600">
                Help keep this free for creators worldwide!
              </p>
            </div>

            <div className="space-y-4 mb-6">
              <div className="bg-blue-50 rounded-lg p-4">
                <h3 className="font-semibold text-blue-900 mb-2">📱 Airtel Money</h3>
                <p className="text-blue-800 font-mono text-lg">{donationDetails.airtel}</p>
              </div>

              <div className="bg-green-50 rounded-lg p-4">
                <h3 className="font-semibold text-green-900 mb-2">🏦 Bank Transfer</h3>
                <div className="text-green-800 space-y-1">
                  <p><span className="font-semibold">Bank:</span> {donationDetails.bank}</p>
                  <p><span className="font-semibold">Account Number:</span> {donationDetails.account}</p>
                  <p><span className="font-semibold">Routing Number:</span> {donationDetails.routing}</p>
                </div>
              </div>
            </div>

            <button
              onClick={copyToClipboard}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 rounded-lg font-semibold hover:shadow-lg transition-all flex items-center justify-center space-x-2 mb-4"
            >
              <SafeIcon icon={FiCopy} />
              <span>Copy Details</span>
            </button>

            <p className="text-center text-sm text-gray-600">
              Every coffee counts — thank you for supporting this dream! ☕
            </p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}