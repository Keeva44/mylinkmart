import React from 'react';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../../common/SafeIcon';

const { FiPalette, FiSun, FiMoon, FiMinimize, FiZap, FiDroplet } = FiIcons;

const themes = [
  {
    name: 'Light',
    icon: FiSun,
    preview: 'bg-white border-gray-200',
    description: 'Clean and bright',
    bodyClass: 'bg-gray-50 text-gray-900'
  },
  {
    name: 'Dark',
    icon: FiMoon,
    preview: 'bg-gray-900 border-gray-700',
    description: 'Sleek and modern',
    bodyClass: 'bg-gray-900 text-white'
  },
  {
    name: 'Minimal',
    icon: FiMinimize,
    preview: 'bg-gray-50 border-gray-300',
    description: 'Simple and elegant',
    bodyClass: 'bg-white text-gray-900'
  },
  {
    name: 'Gradient',
    icon: FiZap,
    preview: 'bg-gradient-to-br from-purple-400 to-pink-500',
    description: 'Vibrant and eye-catching',
    bodyClass: 'bg-gradient-to-br from-purple-400 via-pink-500 to-red-500 text-white'
  },
  {
    name: 'Ocean',
    icon: FiDroplet,
    preview: 'bg-gradient-to-br from-blue-400 to-teal-500',
    description: 'Fresh and calming',
    bodyClass: 'bg-gradient-to-br from-blue-400 via-cyan-500 to-teal-500 text-white'
  }
];

const colors = [
  '#3B82F6', // Blue
  '#EF4444', // Red
  '#10B981', // Green
  '#F59E0B', // Yellow
  '#8B5CF6', // Purple
  '#EC4899', // Pink
  '#06B6D4', // Cyan
  '#84CC16', // Lime
  '#F97316', // Orange
  '#6366F1'  // Indigo
];

export default function ThemeSelector({ theme, onChange }) {
  const handleThemeChange = (themeName) => {
    onChange({
      ...theme,
      name: themeName
    });
  };

  const handleColorChange = (color) => {
    onChange({
      ...theme,
      primaryColor: color
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2 flex items-center">
          <SafeIcon icon={FiPalette} className="mr-3" />
          Theme & Colors
        </h2>
        <p className="text-gray-600">Customize the look and feel of your store</p>
      </div>

      {/* Theme Selection */}
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Choose Theme</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {themes.map((themeOption) => (
            <motion.button
              key={themeOption.name}
              onClick={() => handleThemeChange(themeOption.name)}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className={`p-4 rounded-xl border-2 transition-all ${
                theme.name === themeOption.name
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className={`w-full h-20 rounded-lg mb-3 border ${themeOption.preview}`}>
                <div className="p-3 h-full flex items-center justify-center">
                  <SafeIcon
                    icon={themeOption.icon}
                    className={`text-2xl ${
                      themeOption.name === 'Dark' || themeOption.name === 'Gradient' || themeOption.name === 'Ocean'
                        ? 'text-white'
                        : 'text-gray-600'
                    }`}
                  />
                </div>
              </div>
              <h4 className="font-semibold text-gray-900">{themeOption.name}</h4>
              <p className="text-sm text-gray-600">{themeOption.description}</p>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Color Selection */}
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Accent Color</h3>
        <div className="flex flex-wrap gap-3">
          {colors.map((color) => (
            <button
              key={color}
              onClick={() => handleColorChange(color)}
              className={`w-12 h-12 rounded-full border-2 transition-all hover:scale-110 ${
                theme.primaryColor === color
                  ? 'border-gray-900 ring-2 ring-gray-300'
                  : 'border-gray-300'
              }`}
              style={{ backgroundColor: color }}
            />
          ))}
        </div>

        {/* Custom Color Input */}
        <div className="mt-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Custom Color
          </label>
          <input
            type="color"
            value={theme.primaryColor}
            onChange={(e) => handleColorChange(e.target.value)}
            className="w-20 h-10 rounded-lg border border-gray-300 cursor-pointer"
          />
        </div>
      </div>

      {/* Preview */}
      <div className="bg-gray-50 rounded-lg p-6 border">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Live Preview</h3>
        <div className={`p-6 rounded-lg border ${theme.name === 'Dark' ? 'bg-gray-800 border-gray-700 text-white' :
          theme.name === 'Minimal' ? 'bg-white border-gray-200 text-gray-900' :
          theme.name === 'Gradient' ? 'bg-gradient-to-br from-purple-400 to-pink-500 text-white' :
          theme.name === 'Ocean' ? 'bg-gradient-to-br from-blue-400 to-teal-500 text-white' :
          'bg-white border-gray-200 text-gray-900'
        }`}>
          <div className="text-center">
            <div className="w-16 h-16 rounded-full mx-auto mb-3 bg-gray-300"></div>
            <h4 className="font-semibold mb-2">Your Store Name</h4>
            <p className={`text-sm mb-4 ${theme.name === 'Dark' || theme.name === 'Gradient' || theme.name === 'Ocean' ? 'text-gray-300' : 'text-gray-600'}`}>
              Your bio text will appear here
            </p>
            <div className="space-y-2">
              <button
                className="w-full px-4 py-2 rounded-lg font-semibold text-white text-sm"
                style={{ backgroundColor: theme.primaryColor }}
              >
                Sample Product Button
              </button>
              <div className="flex justify-center space-x-2">
                <div className="w-8 h-8 rounded-full bg-gray-300"></div>
                <div className="w-8 h-8 rounded-full bg-gray-300"></div>
                <div className="w-8 h-8 rounded-full bg-gray-300"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}