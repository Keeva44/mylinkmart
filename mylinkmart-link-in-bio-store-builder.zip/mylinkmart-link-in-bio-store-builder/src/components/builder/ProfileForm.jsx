import React from 'react';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../../common/SafeIcon';
import { handleImageUpload } from '../../utils/helpers';

const { FiUser, FiImage, FiType, FiGlobe } = FiIcons;

export default function ProfileForm({ data, onChange }) {
  const handleInputChange = (field, value) => {
    if (field === 'username') {
      onChange({ ...data, [field]: value });
    } else {
      onChange({
        ...data,
        profile: { ...data.profile, [field]: value }
      });
    }
  };

  const handleImageChange = async (field, event) => {
    const file = event.target.files[0];
    if (file) {
      try {
        const dataUrl = await handleImageUpload(file);
        handleInputChange(field, dataUrl);
      } catch (error) {
        console.error('Error uploading image:', error);
      }
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Profile Setup</h2>
        <p className="text-gray-600">Configure your store's basic information</p>
      </div>

      {/* Username */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          <SafeIcon icon={FiUser} className="inline mr-2" />
          Username (Store URL)
        </label>
        <input
          type="text"
          value={data.username}
          onChange={(e) => handleInputChange('username', e.target.value)}
          placeholder="yourstore"
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          pattern="[a-zA-Z0-9_-]+"
          title="Only letters, numbers, hyphens, and underscores allowed"
        />
        <p className="text-sm text-gray-500 mt-1">
          Your store will be available at: mylinkmart.com/store/{data.username || 'yourstore'}
        </p>
      </div>

      {/* Display Name */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          <SafeIcon icon={FiType} className="inline mr-2" />
          Display Name
        </label>
        <input
          type="text"
          value={data.profile.displayName}
          onChange={(e) => handleInputChange('displayName', e.target.value)}
          placeholder="Your Name or Brand"
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>

      {/* Bio */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Bio</label>
        <textarea
          value={data.profile.bio}
          onChange={(e) => handleInputChange('bio', e.target.value)}
          placeholder="Tell your audience about yourself..."
          rows={4}
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
        />
      </div>

      {/* Profile Image */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          <SafeIcon icon={FiImage} className="inline mr-2" />
          Profile Image
        </label>
        <div className="flex items-center space-x-4">
          {data.profile.profileImage ? (
            <img
              src={data.profile.profileImage}
              alt="Profile"
              className="w-20 h-20 rounded-full object-cover border-2 border-gray-200"
            />
          ) : (
            <div className="w-20 h-20 rounded-full bg-gray-100 border-2 border-gray-200 flex items-center justify-center">
              <SafeIcon icon={FiUser} className="text-gray-400 text-2xl" />
            </div>
          )}
          <div className="flex-1">
            <input
              type="file"
              accept="image/*"
              onChange={(e) => handleImageChange('profileImage', e)}
              className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
            />
            <p className="text-xs text-gray-500 mt-1">Recommended: Square image, at least 200x200px</p>
          </div>
        </div>
      </div>

      {/* Banner Image */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Banner Image (Optional)
        </label>
        <div className="space-y-4">
          {data.profile.bannerImage ? (
            <img
              src={data.profile.bannerImage}
              alt="Banner"
              className="w-full h-40 rounded-lg object-cover border border-gray-200"
            />
          ) : (
            <div className="w-full h-40 rounded-lg bg-gray-100 border-2 border-dashed border-gray-300 flex items-center justify-center">
              <div className="text-center">
                <SafeIcon icon={FiImage} className="text-gray-400 text-3xl mx-auto mb-2" />
                <p className="text-sm text-gray-500">No banner image</p>
              </div>
            </div>
          )}
          <div>
            <input
              type="file"
              accept="image/*"
              onChange={(e) => handleImageChange('bannerImage', e)}
              className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
            />
            <p className="text-xs text-gray-500 mt-1">Recommended: 1200x400px, landscape orientation</p>
          </div>
        </div>
      </div>

      {/* Website URL */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          <SafeIcon icon={FiGlobe} className="inline mr-2" />
          Website URL (Optional)
        </label>
        <input
          type="url"
          value={data.profile.website || ''}
          onChange={(e) => handleInputChange('website', e.target.value)}
          placeholder="https://yourwebsite.com"
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>
    </div>
  );
}