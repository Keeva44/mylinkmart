import React from 'react';
import * as FiIcons from 'react-icons/fi';
import * as SiIcons from 'react-icons/si';
import SafeIcon from '../../common/SafeIcon';

const { FiShare2 } = FiIcons;
const { SiInstagram, SiTiktok, SiYoutube, SiTwitter, SiWhatsapp, SiFacebook, SiLinkedin, SiPinterest, SiThreads } = SiIcons;

const socialPlatforms = [
  { key: 'instagram', label: 'Instagram', icon: SiInstagram, placeholder: 'https://instagram.com/username' },
  { key: 'tiktok', label: 'TikTok', icon: SiTiktok, placeholder: 'https://tiktok.com/@username' },
  { key: 'youtube', label: 'YouTube', icon: SiYoutube, placeholder: 'https://youtube.com/@username' },
  { key: 'twitter', label: 'Twitter/X', icon: SiTwitter, placeholder: 'https://twitter.com/username' },
  { key: 'facebook', label: 'Facebook', icon: SiFacebook, placeholder: 'https://facebook.com/username' },
  { key: 'linkedin', label: 'LinkedIn', icon: SiLinkedin, placeholder: 'https://linkedin.com/in/username' },
  { key: 'whatsapp', label: 'WhatsApp', icon: SiWhatsapp, placeholder: 'https://wa.me/1234567890' },
  { key: 'pinterest', label: 'Pinterest', icon: SiPinterest, placeholder: 'https://pinterest.com/username' },
  { key: 'threads', label: 'Threads', icon: SiThreads, placeholder: 'https://threads.net/@username' }
];

export default function SocialLinksForm({ socialLinks, onChange }) {
  const handleChange = (platform, value) => {
    onChange({
      ...socialLinks,
      [platform]: value
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2 flex items-center">
          <SafeIcon icon={FiShare2} className="mr-3" />
          Social Links
        </h2>
        <p className="text-gray-600">Connect your social media profiles</p>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {socialPlatforms.map((platform) => (
          <div key={platform.key}>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <SafeIcon icon={platform.icon} className="inline mr-2" />
              {platform.label}
            </label>
            <input
              type="url"
              value={socialLinks[platform.key] || ''}
              onChange={(e) => handleChange(platform.key, e.target.value)}
              placeholder={platform.placeholder}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        ))}
      </div>

      <div className="bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-lg p-4">
        <h4 className="font-semibold text-blue-900 mb-2">💡 Pro Tips</h4>
        <ul className="text-sm text-blue-800 space-y-1">
          <li>• Use your complete profile URLs (including https://)</li>
          <li>• WhatsApp links should use the wa.me format with your phone number</li>
          <li>• Leave empty any platforms you don't use</li>
          <li>• Add at least 2-3 platforms to increase engagement</li>
        </ul>
      </div>
    </div>
  );
}