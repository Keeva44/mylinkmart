import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';

const { FiSearch, FiHome, FiPlus } = FiIcons;

export default function StoreNotFound() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center px-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center max-w-md"
      >
        <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-6">
          <SafeIcon icon={FiSearch} className="text-4xl text-gray-400" />
        </div>

        <h1 className="text-3xl font-bold text-gray-900 mb-4">
          Store Not Found
        </h1>

        <p className="text-gray-600 mb-8">
          The store you're looking for doesn't exist or may have been removed.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={() => navigate('/')}
            className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-lg font-semibold hover:shadow-lg transition-all flex items-center justify-center space-x-2"
          >
            <SafeIcon icon={FiHome} />
            <span>Go Home</span>
          </button>

          <button
            onClick={() => navigate('/builder')}
            className="border border-gray-300 text-gray-700 px-6 py-3 rounded-lg font-semibold hover:border-blue-500 hover:text-blue-600 transition-colors flex items-center justify-center space-x-2"
          >
            <SafeIcon icon={FiPlus} />
            <span>Create Store</span>
          </button>
        </div>
      </motion.div>
    </div>
  );
}