import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import * as SiIcons from 'react-icons/si';
import SafeIcon from '../common/SafeIcon';
import { useDonation } from '../contexts/DonationContext';

const { FiX, FiExternalLink, FiHeart } = FiIcons;
const { SiInstagram, SiTiktok, SiYoutube, SiTwitter, SiWhatsapp, SiFacebook, SiLinkedin } = SiIcons;

const socialIcons = {
  instagram: SiInstagram,
  tiktok: SiTiktok,
  youtube: SiYoutube,
  twitter: SiTwitter,
  whatsapp: SiWhatsapp,
  facebook: SiFacebook,
  linkedin: SiLinkedin
};

export default function LivePreview({ storeData, onClose }) {
  const { openDonation } = useDonation();

  const getThemeClasses = () => {
    if (!storeData?.theme) {
      return {
        container: 'bg-gray-50 text-white',
        card: 'bg-white border-gray-200',
        text: 'text-gray-600',
        button: 'bg-blue-600 text-white hover:bg-blue-700'
      };
    }

    const { theme } = storeData;
    switch (theme.name) {
      case 'Dark':
        return {
          container: 'bg-gray-900 text-white',
          card: 'bg-gray-800 border-gray-700',
          text: 'text-gray-300',
          button: 'bg-white text-gray-900 hover:bg-gray-100'
        };
      case 'Minimal':
        return {
          container: 'bg-white text-gray-900',
          card: 'bg-gray-50 border-gray-200',
          text: 'text-gray-600',
          button: 'bg-gray-900 text-white hover:bg-gray-800'
        };
      case 'Gradient':
        return {
          container: 'bg-gradient-to-br from-purple-400 via-pink-500 to-red-500 text-white',
          card: 'bg-white/10 backdrop-blur-sm border-white/20',
          text: 'text-white/90',
          button: 'bg-white text-gray-900 hover:bg-gray-100'
        };
      case 'Ocean':
        return {
          container: 'bg-gradient-to-br from-blue-400 via-cyan-500 to-teal-500 text-white',
          card: 'bg-white/10 backdrop-blur-sm border-white/20',
          text: 'text-white/90',
          button: 'bg-white text-gray-900 hover:bg-gray-100'
        };
      default:
        return {
          container: 'bg-gray-50 text-gray-900',
          card: 'bg-white border-gray-200',
          text: 'text-gray-600',
          button: `bg-blue-600 text-white hover:bg-blue-700`
        };
    }
  };

  const themeClasses = getThemeClasses();

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          onClick={(e) => e.stopPropagation()}
          className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden relative"
        >
          {/* Header */}
          <div className="bg-gray-100 px-6 py-4 border-b flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">Store Preview</h3>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => window.open(`#/store/${storeData.username}`, '_blank')}
                className="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700 transition-colors"
              >
                Open Full Page
              </button>
              <button
                onClick={onClose}
                className="text-gray-600 hover:text-gray-900 transition-colors"
              >
                <SafeIcon icon={FiX} className="text-xl" />
              </button>
            </div>
          </div>

          {/* Preview Content */}
          <div className="overflow-y-auto max-h-[calc(90vh-80px)]">
            <div className={`${themeClasses.container} min-h-screen`}>
              <div className="container mx-auto px-6 py-8 max-w-2xl">
                {/* Banner Image */}
                {storeData.profile.bannerImage && (
                  <div className="mb-8">
                    <img
                      src={storeData.profile.bannerImage}
                      alt="Banner"
                      className="w-full h-48 object-cover rounded-2xl"
                    />
                  </div>
                )}

                {/* Profile Section */}
                <div className="text-center mb-8">
                  {storeData.profile.profileImage && (
                    <div className="mb-6">
                      <img
                        src={storeData.profile.profileImage}
                        alt={storeData.profile.displayName}
                        className="w-24 h-24 rounded-full mx-auto object-cover border-4 border-white shadow-lg"
                      />
                    </div>
                  )}

                  <h1 className="text-3xl font-bold mb-2">
                    {storeData.profile.displayName || storeData.username}
                  </h1>

                  {storeData.profile.bio && (
                    <p className={`text-lg mb-6 ${themeClasses.text} max-w-lg mx-auto`}>
                      {storeData.profile.bio}
                    </p>
                  )}

                  {/* Website Link */}
                  {storeData.profile.website && (
                    <a
                      href={storeData.profile.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`inline-flex items-center space-x-2 ${themeClasses.text} hover:underline mb-6`}
                    >
                      <span>🌐 Website</span>
                      <SafeIcon icon={FiExternalLink} className="text-sm" />
                    </a>
                  )}

                  {/* Social Links */}
                  {Object.keys(storeData.socialLinks).length > 0 && (
                    <div className="flex justify-center space-x-4 mb-8">
                      {Object.entries(storeData.socialLinks).map(([platform, url]) => {
                        if (!url) return null;
                        const IconComponent = socialIcons[platform];
                        return (
                          <a
                            key={platform}
                            href={url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className={`p-3 rounded-full ${themeClasses.card} border hover:scale-110 transition-transform`}
                          >
                            {IconComponent ? (
                              <SafeIcon icon={IconComponent} className="text-xl" />
                            ) : (
                              <SafeIcon icon={FiExternalLink} className="text-xl" />
                            )}
                          </a>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Products Grid */}
                {storeData.products.length > 0 && (
                  <div className="space-y-4 mb-12">
                    <h2 className="text-2xl font-bold text-center mb-6">Featured Products</h2>
                    {storeData.products.map((product, index) => (
                      <div
                        key={index}
                        className={`${themeClasses.card} border rounded-2xl p-6 hover:shadow-lg transition-all`}
                      >
                        <div className="flex items-center space-x-4">
                          {product.image ? (
                            <img
                              src={product.image}
                              alt={product.name}
                              className="w-16 h-16 object-cover rounded-xl flex-shrink-0"
                            />
                          ) : (
                            <div className="w-16 h-16 rounded-xl bg-gray-200 flex items-center justify-center">
                              <SafeIcon icon={FiExternalLink} className="text-gray-400" />
                            </div>
                          )}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center space-x-2 mb-1">
                              <h3 className="text-lg font-semibold">{product.name}</h3>
                              {product.price && (
                                <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full font-semibold">
                                  {product.price}
                                </span>
                              )}
                            </div>
                            {product.description && (
                              <p className={`${themeClasses.text} text-sm mb-3`}>
                                {product.description}
                              </p>
                            )}
                            <a
                              href={product.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className={`inline-flex items-center space-x-2 px-4 py-2 rounded-lg font-semibold transition-colors ${themeClasses.button}`}
                            >
                              <span>View Product</span>
                              <SafeIcon icon={FiExternalLink} className="text-sm" />
                            </a>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Empty State */}
                {storeData.products.length === 0 && (
                  <div className="text-center py-12">
                    <p className={`${themeClasses.text} text-lg`}>
                      No products added yet. This is how your store will look!
                    </p>
                  </div>
                )}

                {/* Footer */}
                <footer className="text-center pt-8 border-t border-gray-200">
                  <p className={`text-sm ${themeClasses.text} mb-2`}>
                    Built with ❤️ using MyLinkMart
                  </p>
                  <button
                    onClick={openDonation}
                    className={`text-sm ${themeClasses.text} hover:text-red-500 transition-colors flex items-center space-x-1 mx-auto`}
                  >
                    <SafeIcon icon={FiHeart} />
                    <span>💖 Support MyLinkMart Project</span>
                  </button>
                </footer>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}