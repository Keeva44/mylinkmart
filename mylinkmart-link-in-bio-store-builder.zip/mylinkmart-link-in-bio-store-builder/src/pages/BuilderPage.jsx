import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';
import { useDonation } from '../contexts/DonationContext';
import ProfileForm from '../components/builder/ProfileForm';
import ProductsManager from '../components/builder/ProductsManager';
import SocialLinksForm from '../components/builder/SocialLinksForm';
import ThemeSelector from '../components/builder/ThemeSelector';
import EmailCaptureModal from '../components/EmailCaptureModal';
import LivePreview from '../components/LivePreview';
import {
  saveStore,
  getStore,
  checkUsernameExists,
  showToast,
  exportStore,
  downloadEmailsCSV,
  generateQRCode
} from '../utils/helpers';

const { FiArrowLeft, FiSave, FiEye, FiDownload, FiUsers, FiHeart, FiShare2 } = FiIcons;

export default function BuilderPage() {
  const navigate = useNavigate();
  const { openDonation } = useDonation();
  const [activeTab, setActiveTab] = useState('profile');
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [showLivePreview, setShowLivePreview] = useState(false);
  const [qrCode, setQrCode] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  
  const [storeData, setStoreData] = useState({
    username: '',
    profile: {
      displayName: '',
      bio: '',
      profileImage: '',
      bannerImage: '',
      website: ''
    },
    products: [],
    socialLinks: {},
    theme: {
      name: 'Light',
      primaryColor: '#3B82F6'
    }
  });

  const tabs = [
    { id: 'profile', label: 'Profile', icon: FiUsers },
    { id: 'products', label: 'Products', icon: FiDownload },
    { id: 'social', label: 'Social', icon: FiHeart },
    { id: 'theme', label: 'Theme', icon: FiEye }
  ];

  useEffect(() => {
    // Load existing store data if editing
    const urlParams = new URLSearchParams(window.location.search);
    const editUsername = urlParams.get('edit');
    if (editUsername) {
      const existingStore = getStore(editUsername);
      if (existingStore) {
        setStoreData(existingStore);
      }
    }
  }, []);

  const handleSave = async () => {
    if (!storeData.username.trim()) {
      showToast('Please enter a username', 'error');
      return;
    }

    if (!/^[a-zA-Z0-9_-]+$/.test(storeData.username)) {
      showToast('Username can only contain letters, numbers, hyphens, and underscores', 'error');
      return;
    }

    const urlParams = new URLSearchParams(window.location.search);
    const isEditing = urlParams.get('edit');

    if (!isEditing && checkUsernameExists(storeData.username)) {
      showToast('Username already exists. Please choose a different one.', 'error');
      return;
    }

    setIsSaving(true);
    try {
      saveStore(storeData.username, storeData);
      showToast('Store saved successfully! 🎉', 'success');
    } catch (error) {
      console.error('Save error:', error);
      showToast('Failed to save store. Please try again.', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handlePreview = () => {
    if (!storeData.username.trim()) {
      showToast('Please enter a username and save first', 'error');
      return;
    }

    // Check if user has provided email in this session
    const sessionEmail = sessionStorage.getItem('mylinkmart_session_email');
    if (!sessionEmail) {
      setShowEmailModal(true);
      return;
    }

    setShowLivePreview(true);
  };

  const handleExport = async () => {
    if (!storeData.username.trim()) {
      showToast('Please enter a username and save first', 'error');
      return;
    }

    // Check if user has provided email in this session
    const sessionEmail = sessionStorage.getItem('mylinkmart_session_email');
    if (!sessionEmail) {
      setShowEmailModal(true);
      return;
    }

    try {
      await exportStore(storeData);
      showToast('Store exported successfully! 📦', 'success');
    } catch (error) {
      console.error('Export error:', error);
      showToast('Export failed. Please try again.', 'error');
    }
  };

  const handleShare = async () => {
    if (!storeData.username.trim()) {
      showToast('Please enter a username and save first', 'error');
      return;
    }

    const shareUrl = `${window.location.origin}${window.location.pathname}#/store/${storeData.username}`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: `${storeData.profile.displayName || storeData.username}'s Store`,
          text: 'Check out my store on MyLinkMart!',
          url: shareUrl
        });
        showToast('Store shared successfully! 🚀', 'success');
      } catch (error) {
        // Fallback to clipboard if share fails
        copyToClipboard(shareUrl);
      }
    } else {
      copyToClipboard(shareUrl);
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text).then(() => {
      showToast('Store link copied to clipboard! 📋', 'success');
    }).catch(() => {
      showToast('Failed to copy link', 'error');
    });
  };

  const handleEmailModalSubmit = (email) => {
    sessionStorage.setItem('mylinkmart_session_email', email);
    setShowEmailModal(false);
    setShowLivePreview(true);
  };

  const generateStoreQR = async () => {
    if (!storeData.username.trim()) {
      showToast('Please enter a username first', 'error');
      return;
    }

    try {
      const storeUrl = `${window.location.origin}${window.location.pathname}#/store/${storeData.username}`;
      const qrDataUrl = await generateQRCode(storeUrl);
      setQrCode(qrDataUrl);
      showToast('QR code generated! 📱', 'success');
    } catch (error) {
      console.error('QR generation error:', error);
      showToast('Failed to generate QR code', 'error');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b sticky top-0 z-40">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/')}
                className="flex items-center space-x-2 text-gray-600 hover:text-blue-600 transition-colors"
              >
                <SafeIcon icon={FiArrowLeft} />
                <span>Back to Home</span>
              </button>
              <div className="hidden sm:block w-px h-6 bg-gray-300" />
              <h1 className="text-xl font-semibold text-gray-900">Store Builder</h1>
            </div>

            <div className="flex items-center space-x-3">
              <button
                onClick={downloadEmailsCSV}
                className="text-gray-600 hover:text-blue-600 transition-colors p-2 rounded-lg hover:bg-gray-100"
                title="Download Collected Emails"
              >
                <SafeIcon icon={FiDownload} />
              </button>
              <button
                onClick={openDonation}
                className="text-gray-600 hover:text-red-600 transition-colors p-2 rounded-lg hover:bg-gray-100"
                title="Support MyLinkMart"
              >
                <SafeIcon icon={FiHeart} />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar Navigation */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm p-6 sticky top-24">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Build Your Store</h2>
              <nav className="space-y-2">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-colors ${
                      activeTab === tab.id
                        ? 'bg-blue-50 text-blue-600 border border-blue-200'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <SafeIcon icon={tab.icon} className="text-sm" />
                    <span>{tab.label}</span>
                  </button>
                ))}
              </nav>

              {/* Action Buttons */}
              <div className="mt-8 space-y-3">
                <button
                  onClick={handleSave}
                  disabled={isSaving}
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 rounded-lg font-semibold hover:shadow-lg transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
                >
                  <SafeIcon icon={FiSave} />
                  <span>{isSaving ? 'Saving...' : 'Save Store'}</span>
                </button>

                <button
                  onClick={handlePreview}
                  className="w-full border border-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:border-blue-500 hover:text-blue-600 transition-colors flex items-center justify-center space-x-2"
                >
                  <SafeIcon icon={FiEye} />
                  <span>Live Preview</span>
                </button>

                <button
                  onClick={handleShare}
                  className="w-full bg-gradient-to-r from-green-600 to-teal-600 text-white py-3 rounded-lg font-semibold hover:shadow-lg transition-all flex items-center justify-center space-x-2"
                >
                  <SafeIcon icon={FiShare2} />
                  <span>Share Store</span>
                </button>

                <button
                  onClick={handleExport}
                  className="w-full bg-gradient-to-r from-orange-600 to-red-600 text-white py-3 rounded-lg font-semibold hover:shadow-lg transition-all flex items-center justify-center space-x-2"
                >
                  <SafeIcon icon={FiDownload} />
                  <span>Export HTML</span>
                </button>

                <button
                  onClick={generateStoreQR}
                  className="w-full border border-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:border-green-500 hover:text-green-600 transition-colors"
                >
                  Generate QR Code
                </button>
              </div>

              {/* QR Code Display */}
              {qrCode && (
                <div className="mt-6 p-4 bg-gray-50 rounded-lg text-center">
                  <img src={qrCode} alt="Store QR Code" className="mx-auto mb-2" />
                  <p className="text-sm text-gray-600">Share your store QR code</p>
                </div>
              )}
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-xl shadow-sm">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3 }}
                className="p-6"
              >
                {activeTab === 'profile' && (
                  <ProfileForm
                    data={storeData}
                    onChange={setStoreData}
                  />
                )}
                {activeTab === 'products' && (
                  <ProductsManager
                    products={storeData.products}
                    onChange={(products) => setStoreData(prev => ({ ...prev, products }))}
                  />
                )}
                {activeTab === 'social' && (
                  <SocialLinksForm
                    socialLinks={storeData.socialLinks}
                    onChange={(socialLinks) => setStoreData(prev => ({ ...prev, socialLinks }))}
                  />
                )}
                {activeTab === 'theme' && (
                  <ThemeSelector
                    theme={storeData.theme}
                    onChange={(theme) => setStoreData(prev => ({ ...prev, theme }))}
                  />
                )}
              </motion.div>
            </div>
          </div>
        </div>
      </div>

      {/* Email Capture Modal */}
      {showEmailModal && (
        <EmailCaptureModal
          onSubmit={handleEmailModalSubmit}
          onClose={() => setShowEmailModal(false)}
        />
      )}

      {/* Live Preview Modal */}
      {showLivePreview && (
        <LivePreview
          storeData={storeData}
          onClose={() => setShowLivePreview(false)}
        />
      )}
    </div>
  );
}