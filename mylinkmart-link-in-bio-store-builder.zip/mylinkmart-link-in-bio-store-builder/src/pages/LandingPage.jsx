import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';
import { useDonation } from '../contexts/DonationContext';
import { validateEmail, saveEmail, showToast } from '../utils/helpers';

const { FiArrowRight, FiHeart, FiStar, FiUsers, FiTrendingUp, FiZap, FiStore } = FiIcons;

export default function LandingPage() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { openDonation } = useDonation();

  const handleEmailSubmit = async (e) => {
    e.preventDefault();
    if (!validateEmail(email)) {
      showToast('Please enter a valid email address', 'error');
      return;
    }

    setLoading(true);
    try {
      saveEmail(email);
      showToast('Email saved successfully! Welcome to MyLinkMart 🎉', 'success');
      setEmail('');
    } catch (error) {
      showToast('Something went wrong. Please try again.', 'error');
    }
    setLoading(false);
  };

  const features = [
    {
      icon: FiZap,
      title: 'Lightning Fast Setup',
      description: 'Create your store in under 5 minutes with our intuitive builder'
    },
    {
      icon: FiTrendingUp,
      title: 'Affiliate Ready',
      description: 'Built specifically for affiliate marketers and content creators'
    },
    {
      icon: FiUsers,
      title: 'Mobile First',
      description: 'Perfect experience on all devices - your audience is mobile'
    },
    {
      icon: FiStar,
      title: 'Free Forever',
      description: 'No hidden costs, no subscriptions. Build unlimited stores'
    },
    {
      icon: FiStore,
      title: 'Modern Design',
      description: 'Beautiful, responsive stores that convert visitors into customers'
    },
    {
      icon: FiHeart,
      title: 'Creator Focused',
      description: 'Every feature designed to help you monetize your audience'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Navigation */}
      <nav className="container mx-auto px-6 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
              <SafeIcon icon={FiHeart} className="text-white text-sm" />
            </div>
            <span className="text-xl font-bold text-gray-900">MyLinkMart</span>
          </div>
          <div className="flex items-center space-x-4">
            <button
              onClick={() => navigate('/builder')}
              className="hidden sm:flex items-center space-x-2 text-gray-600 hover:text-blue-600 transition-colors"
            >
              <span>Create Store</span>
            </button>
            <button
              onClick={openDonation}
              className="flex items-center space-x-2 text-gray-600 hover:text-blue-600 transition-colors"
            >
              <SafeIcon icon={FiHeart} className="text-sm" />
              <span className="hidden sm:inline">Support Project</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container mx-auto px-6 py-20">
        <div className="text-center max-w-4xl mx-auto">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight"
          >
            Turn Your Bio Into a{' '}
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Mini Affiliate Store
            </span>
            {' '} — Free Forever
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-gray-600 mb-12 max-w-2xl mx-auto"
          >
            Create beautiful Link-in-Bio pages with integrated affiliate products. 
            No coding required, no monthly fees, unlimited stores.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-16"
          >
            <button
              onClick={() => navigate('/builder')}
              className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-4 rounded-xl font-semibold flex items-center space-x-2 hover:shadow-lg transition-all transform hover:scale-105"
            >
              <span>Create Your Store</span>
              <SafeIcon icon={FiArrowRight} />
            </button>

            <button
              onClick={openDonation}
              className="border-2 border-gray-300 text-gray-700 px-8 py-4 rounded-xl font-semibold flex items-center space-x-2 hover:border-blue-500 hover:text-blue-600 transition-all"
            >
              <SafeIcon icon={FiHeart} />
              <span>Support MyLinkMart</span>
            </button>
          </motion.div>

          {/* Email Capture */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="max-w-md mx-auto"
          >
            <form onSubmit={handleEmailSubmit} className="flex flex-col sm:flex-row gap-3">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email for updates"
                className="flex-1 px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              />
              <button
                type="submit"
                disabled={loading}
                className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors disabled:opacity-50"
              >
                {loading ? 'Saving...' : 'Get Updates'}
              </button>
            </form>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-6 py-20">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Why Creators Love MyLinkMart
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Built by creators, for creators. Everything you need to monetize your audience.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-lg transition-all border border-gray-100"
            >
              <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center mb-6">
                <SafeIcon icon={feature.icon} className="text-white text-xl" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                {feature.title}
              </h3>
              <p className="text-gray-600">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-6 text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-6 h-6 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
              <SafeIcon icon={FiHeart} className="text-white text-xs" />
            </div>
            <span className="text-lg font-semibold">MyLinkMart</span>
          </div>
          <p className="text-gray-400 mb-4">
            Empowering creators worldwide with free Link-in-Bio tools
          </p>
          <button
            onClick={openDonation}
            className="text-blue-400 hover:text-blue-300 transition-colors flex items-center space-x-2 mx-auto"
          >
            <SafeIcon icon={FiHeart} />
            <span>💖 Support MyLinkMart Project</span>
          </button>
        </div>
      </footer>
    </div>
  );
}