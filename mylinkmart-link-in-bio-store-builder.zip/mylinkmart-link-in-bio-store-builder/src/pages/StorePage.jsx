import React, { useState, useEffect } from 'react';
import { useParams, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import * as SiIcons from 'react-icons/si';
import SafeIcon from '../common/SafeIcon';
import { useDonation } from '../contexts/DonationContext';
import { getStore, incrementStoreViews } from '../utils/helpers';
import StoreNotFound from '../components/StoreNotFound';

const { FiExternalLink, FiHeart, FiGlobe } = FiIcons;
const { SiInstagram, SiTiktok, SiYoutube, SiTwitter, SiWhatsapp, SiFacebook, SiLinkedin } = SiIcons;

const socialIcons = {
  instagram: SiInstagram,
  tiktok: SiTiktok,
  youtube: SiYoutube,
  twitter: SiTwitter,
  whatsapp: SiWhatsapp,
  facebook: SiFacebook,
  linkedin: SiLinkedin
};

export default function StorePage() {
  const { username } = useParams();
  const location = useLocation();
  const { openDonation } = useDonation();
  const [storeData, setStoreData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const loadStore = () => {
      try {
        // Get username from URL params or query string
        const urlParams = new URLSearchParams(location.search);
        const queryUsername = urlParams.get('user') || username;

        if (!queryUsername) {
          setError('No username provided');
          return;
        }

        const store = getStore(queryUsername);
        if (store) {
          setStoreData(store);
          incrementStoreViews(queryUsername);
        } else {
          setError('Store not found');
        }
      } catch (err) {
        console.error('Error loading store:', err);
        setError('Failed to load store');
      } finally {
        setLoading(false);
      }
    };

    loadStore();
  }, [username, location.search]);

  const getThemeClasses = () => {
    if (!storeData?.theme) {
      return {
        container: 'bg-gray-50 text-gray-900 min-h-screen',
        card: 'bg-white border-gray-200',
        text: 'text-gray-600',
        button: 'bg-blue-600 text-white hover:bg-blue-700'
      };
    }

    const { theme } = storeData;
    switch (theme.name) {
      case 'Dark':
        return {
          container: 'bg-gray-900 text-white min-h-screen',
          card: 'bg-gray-800 border-gray-700',
          text: 'text-gray-300',
          button: 'bg-white text-gray-900 hover:bg-gray-100'
        };
      case 'Minimal':
        return {
          container: 'bg-white text-gray-900 min-h-screen',
          card: 'bg-gray-50 border-gray-200',
          text: 'text-gray-600',
          button: 'bg-gray-900 text-white hover:bg-gray-800'
        };
      case 'Gradient':
        return {
          container: 'bg-gradient-to-br from-purple-400 via-pink-500 to-red-500 text-white min-h-screen',
          card: 'bg-white/10 backdrop-blur-sm border-white/20',
          text: 'text-white/90',
          button: 'bg-white text-gray-900 hover:bg-gray-100'
        };
      case 'Ocean':
        return {
          container: 'bg-gradient-to-br from-blue-400 via-cyan-500 to-teal-500 text-white min-h-screen',
          card: 'bg-white/10 backdrop-blur-sm border-white/20',
          text: 'text-white/90',
          button: 'bg-white text-gray-900 hover:bg-gray-100'
        };
      default:
        return {
          container: 'bg-gray-50 text-gray-900 min-h-screen',
          card: 'bg-white border-gray-200',
          text: 'text-gray-600',
          button: `bg-blue-600 text-white hover:bg-blue-700`
        };
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-blue-600 border-t-transparent mx-auto mb-4"></div>
          <p className="text-gray-600">Loading store...</p>
        </div>
      </div>
    );
  }

  if (error || !storeData) {
    return <StoreNotFound />;
  }

  const themeClasses = getThemeClasses();

  return (
    <div className={themeClasses.container}>
      <div className="container mx-auto px-6 py-8 max-w-2xl">
        {/* Banner Image */}
        {storeData.profile.bannerImage && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <img
              src={storeData.profile.bannerImage}
              alt="Banner"
              className="w-full h-48 object-cover rounded-2xl shadow-lg"
              loading="lazy"
            />
          </motion.div>
        )}

        {/* Profile Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-center mb-8"
        >
          {storeData.profile.profileImage && (
            <div className="mb-6">
              <img
                src={storeData.profile.profileImage}
                alt={storeData.profile.displayName}
                className="w-24 h-24 rounded-full mx-auto object-cover border-4 border-white shadow-lg"
                loading="lazy"
              />
            </div>
          )}

          <h1 className="text-3xl md:text-4xl font-bold mb-2">
            {storeData.profile.displayName || storeData.username}
          </h1>

          {storeData.profile.bio && (
            <p className={`text-lg mb-6 ${themeClasses.text} max-w-lg mx-auto`}>
              {storeData.profile.bio}
            </p>
          )}

          {/* Website Link */}
          {storeData.profile.website && (
            <a
              href={storeData.profile.website}
              target="_blank"
              rel="noopener noreferrer"
              className={`inline-flex items-center space-x-2 ${themeClasses.text} hover:underline mb-6`}
            >
              <span>🌐 Website</span>
              <SafeIcon icon={FiGlobe} className="text-sm" />
            </a>
          )}

          {/* Social Links */}
          {Object.keys(storeData.socialLinks).length > 0 && (
            <div className="flex justify-center space-x-4 mb-8">
              {Object.entries(storeData.socialLinks).map(([platform, url]) => {
                if (!url) return null;
                const IconComponent = socialIcons[platform];
                return (
                  <a
                    key={platform}
                    href={url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`p-3 rounded-full ${themeClasses.card} border hover:scale-110 transition-transform`}
                  >
                    {IconComponent ? (
                      <SafeIcon icon={IconComponent} className="text-xl" />
                    ) : (
                      <SafeIcon icon={FiExternalLink} className="text-xl" />
                    )}
                  </a>
                );
              })}
            </div>
          )}
        </motion.div>

        {/* Products Grid */}
        {storeData.products.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="space-y-4 mb-12"
          >
            <h2 className="text-2xl md:text-3xl font-bold text-center mb-8">Featured Products</h2>
            {storeData.products.map((product, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 + index * 0.1 }}
                className={`${themeClasses.card} border rounded-2xl p-6 hover:shadow-lg transition-all`}
              >
                <div className="flex items-center space-x-4">
                  {product.image ? (
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-16 h-16 object-cover rounded-xl flex-shrink-0"
                      loading="lazy"
                    />
                  ) : (
                    <div className="w-16 h-16 rounded-xl bg-gray-200 flex items-center justify-center">
                      <SafeIcon icon={FiExternalLink} className="text-gray-400" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 mb-1">
                      <h3 className="text-lg font-semibold">{product.name}</h3>
                      {product.price && (
                        <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full font-semibold">
                          {product.price}
                        </span>
                      )}
                    </div>
                    {product.description && (
                      <p className={`${themeClasses.text} text-sm mb-3`}>
                        {product.description}
                      </p>
                    )}
                    <a
                      href={product.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`inline-flex items-center space-x-2 px-4 py-2 rounded-lg font-semibold transition-colors ${themeClasses.button}`}
                    >
                      <span>View Product</span>
                      <SafeIcon icon={FiExternalLink} className="text-sm" />
                    </a>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        )}

        {/* Empty State */}
        {storeData.products.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <p className={`${themeClasses.text} text-lg`}>
              No products available yet. Check back soon!
            </p>
          </motion.div>
        )}

        {/* Footer */}
        <footer className="text-center pt-8 border-t border-gray-200">
          <p className={`text-sm ${themeClasses.text} mb-2`}>
            Built with ❤️ using MyLinkMart
          </p>
          <button
            onClick={openDonation}
            className={`text-sm ${themeClasses.text} hover:text-red-500 transition-colors flex items-center space-x-1 mx-auto`}
          >
            <SafeIcon icon={FiHeart} />
            <span>💖 Support MyLinkMart Project</span>
          </button>
        </footer>
      </div>
    </div>
  );
}