import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import './index.css';
import LandingPage from './pages/LandingPage';
import BuilderPage from './pages/BuilderPage';
import StorePage from './pages/StorePage';
import { DonationProvider } from './contexts/DonationContext';
import DonationModal from './components/DonationModal';

function App() {
  return (
    <DonationProvider>
      <Router>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/builder" element={<BuilderPage />} />
          <Route path="/store" element={<StorePage />} />
          <Route path="/store/:username" element={<StorePage />} />
          <Route path="*" element={<LandingPage />} />
        </Routes>
        <DonationModal />
      </Router>
    </DonationProvider>
  );
}

const rootElement = document.getElementById('root');
if (rootElement) {
  const root = createRoot(rootElement);
  root.render(
    <StrictMode>
      <App />
    </StrictMode>
  );
} else {
  console.error('Root element not found');
}