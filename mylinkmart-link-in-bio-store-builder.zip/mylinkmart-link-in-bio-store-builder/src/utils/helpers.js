import JSZip from 'jszip';
import QRCode from 'qrcode';

// Email validation
export function validateEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

// Toast notifications
export function showToast(message, type = 'info') {
  // Remove existing toast
  const existingToast = document.querySelector('.toast-notification');
  if (existingToast) {
    existingToast.remove();
  }

  const toast = document.createElement('div');
  toast.className = `toast-notification fixed top-4 right-4 px-6 py-3 rounded-lg shadow-lg z-50 transition-all duration-300 ${
    type === 'success' ? 'bg-green-500 text-white' :
    type === 'error' ? 'bg-red-500 text-white' :
    'bg-blue-500 text-white'
  }`;
  toast.textContent = message;

  document.body.appendChild(toast);

  // Animate in
  requestAnimationFrame(() => {
    toast.style.transform = 'translateX(0)';
  });

  // Remove after 3 seconds
  setTimeout(() => {
    toast.style.transform = 'translateX(100%)';
    setTimeout(() => {
      if (toast.parentNode) {
        toast.parentNode.removeChild(toast);
      }
    }, 300);
  }, 3000);
}

// Email management
export function saveEmail(email) {
  try {
    const emails = getEmails();
    if (!emails.includes(email)) {
      emails.push(email);
      localStorage.setItem('mylinkmart_emails', JSON.stringify(emails));
    }
  } catch (error) {
    console.error('Error saving email:', error);
  }
}

export function getEmails() {
  try {
    const emails = localStorage.getItem('mylinkmart_emails');
    return emails ? JSON.parse(emails) : [];
  } catch (error) {
    console.error('Error getting emails:', error);
    return [];
  }
}

// Store management
export function saveStore(username, storeData) {
  try {
    const stores = getStores();
    stores[username] = { ...storeData, updatedAt: new Date().toISOString() };
    localStorage.setItem('mylinkmart_stores', JSON.stringify(stores));
  } catch (error) {
    console.error('Error saving store:', error);
    throw error;
  }
}

export function getStore(username) {
  try {
    const stores = getStores();
    return stores[username] || null;
  } catch (error) {
    console.error('Error getting store:', error);
    return null;
  }
}

export function getStores() {
  try {
    const stores = localStorage.getItem('mylinkmart_stores');
    return stores ? JSON.parse(stores) : {};
  } catch (error) {
    console.error('Error getting stores:', error);
    return {};
  }
}

export function checkUsernameExists(username) {
  try {
    const stores = getStores();
    return stores.hasOwnProperty(username);
  } catch (error) {
    console.error('Error checking username:', error);
    return false;
  }
}

// Analytics
export function incrementStoreViews(username) {
  try {
    const views = getStoreViews();
    views[username] = (views[username] || 0) + 1;
    localStorage.setItem('mylinkmart_views', JSON.stringify(views));
  } catch (error) {
    console.error('Error incrementing views:', error);
  }
}

export function getStoreViews() {
  try {
    const views = localStorage.getItem('mylinkmart_views');
    return views ? JSON.parse(views) : {};
  } catch (error) {
    console.error('Error getting views:', error);
    return {};
  }
}

// Image handling
export function handleImageUpload(file) {
  return new Promise((resolve, reject) => {
    if (file.size > 5 * 1024 * 1024) { // 5MB limit
      reject(new Error('File size must be less than 5MB'));
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        resolve(e.target.result);
      } catch (error) {
        reject(error);
      }
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}

// Export functionality
export async function exportStore(storeData) {
  try {
    const zip = new JSZip();
    
    // Generate HTML content
    const htmlContent = generateStoreHTML(storeData);
    zip.file('index.html', htmlContent);
    
    // Add assets if needed
    const assets = zip.folder('assets');
    
    // Generate and download ZIP
    const content = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(content);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${storeData.username}-store.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  } catch (error) {
    console.error('Export error:', error);
    throw error;
  }
}

// Generate static HTML for export
function generateStoreHTML(storeData) {
  const themeStyles = getThemeStyles(storeData.theme);
  
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${storeData.profile.displayName || storeData.username} - Store</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Inter', sans-serif; }
    ${themeStyles}
  </style>
</head>
<body class="${getBodyClasses(storeData.theme)}">
  <div class="container mx-auto px-6 py-8 max-w-2xl">
    ${storeData.profile.bannerImage ? `
    <div class="mb-8">
      <img src="${storeData.profile.bannerImage}" alt="Banner" class="w-full h-48 object-cover rounded-2xl shadow-lg">
    </div>
    ` : ''}
    
    <div class="text-center mb-8">
      ${storeData.profile.profileImage ? `
      <div class="mb-6">
        <img src="${storeData.profile.profileImage}" alt="${storeData.profile.displayName}" class="w-24 h-24 rounded-full mx-auto object-cover border-4 border-white shadow-lg">
      </div>
      ` : ''}
      
      <h1 class="text-3xl md:text-4xl font-bold mb-2">${storeData.profile.displayName || storeData.username}</h1>
      
      ${storeData.profile.bio ? `
      <p class="text-lg mb-6 text-gray-600 max-w-lg mx-auto">${storeData.profile.bio}</p>
      ` : ''}
      
      ${storeData.profile.website ? `
      <a href="${storeData.profile.website}" target="_blank" rel="noopener noreferrer" class="inline-flex items-center space-x-2 text-gray-600 hover:underline mb-6">
        <span>🌐 Website</span>
        <span>↗</span>
      </a>
      ` : ''}
      
      ${generateSocialLinks(storeData.socialLinks)}
    </div>
    
    ${generateProductsHTML(storeData.products, storeData.theme)}
    
    <footer class="text-center pt-8 border-t border-gray-200">
      <p class="text-sm text-gray-600 mb-2">Built with ❤️ using MyLinkMart</p>
      <p class="text-sm text-gray-500">💖 Powered by MyLinkMart</p>
    </footer>
  </div>
</body>
</html>`;
}

function getThemeStyles(theme) {
  return `
    .theme-button {
      background-color: ${theme.primaryColor};
      color: white;
    }
    .theme-button:hover {
      opacity: 0.9;
    }
  `;
}

function getBodyClasses(theme) {
  switch (theme.name) {
    case 'Dark':
      return 'bg-gray-900 text-white min-h-screen';
    case 'Minimal':
      return 'bg-white text-gray-900 min-h-screen';
    case 'Gradient':
      return 'bg-gradient-to-br from-purple-400 via-pink-500 to-red-500 text-white min-h-screen';
    case 'Ocean':
      return 'bg-gradient-to-br from-blue-400 via-cyan-500 to-teal-500 text-white min-h-screen';
    default:
      return 'bg-gray-50 text-gray-900 min-h-screen';
  }
}

function generateSocialLinks(socialLinks) {
  const links = Object.entries(socialLinks)
    .filter(([_, url]) => url)
    .map(([platform, url]) => `
      <a href="${url}" target="_blank" rel="noopener noreferrer" 
         class="p-3 rounded-full bg-white/10 hover:bg-white/20 transition-all inline-block">
        ${platform}
      </a>
    `).join('');
    
  return links ? `<div class="flex justify-center space-x-4 mb-8">${links}</div>` : '';
}

function generateProductsHTML(products, theme) {
  if (!products.length) return '';
  
  const productItems = products.map(product => `
    <div class="bg-white border rounded-2xl p-6 hover:shadow-lg transition-all mb-4">
      <div class="flex items-center space-x-4">
        ${product.image ? `
        <img src="${product.image}" alt="${product.name}" class="w-16 h-16 object-cover rounded-xl flex-shrink-0">
        ` : `
        <div class="w-16 h-16 rounded-xl bg-gray-200 flex items-center justify-center">
          <span>↗</span>
        </div>
        `}
        <div class="flex-1 min-w-0">
          <div class="flex items-center space-x-2 mb-1">
            <h3 class="text-lg font-semibold mb-1 text-gray-900">${product.name}</h3>
            ${product.price ? `
            <span class="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full font-semibold">
              ${product.price}
            </span>
            ` : ''}
          </div>
          ${product.description ? `
          <p class="text-gray-600 text-sm mb-3">${product.description}</p>
          ` : ''}
          <a href="${product.url}" target="_blank" rel="noopener noreferrer" 
             class="theme-button inline-flex items-center space-x-2 px-4 py-2 rounded-lg font-semibold transition-colors">
            <span>View Product</span>
            <span>↗</span>
          </a>
        </div>
      </div>
    </div>
  `).join('');
  
  return `
    <div class="space-y-4 mb-12">
      <h2 class="text-2xl md:text-3xl font-bold text-center mb-8">Featured Products</h2>
      ${productItems}
    </div>
  `;
}

// CSV Export
export function downloadEmailsCSV() {
  try {
    const emails = getEmails();
    if (emails.length === 0) {
      showToast('No emails to download', 'error');
      return;
    }

    const csvContent = 'Email\n' + emails.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `mylinkmart-emails-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    showToast(`Downloaded ${emails.length} emails`, 'success');
  } catch (error) {
    console.error('CSV download error:', error);
    showToast('Failed to download emails', 'error');
  }
}

// QR Code generation
export async function generateQRCode(url) {
  try {
    const qrDataUrl = await QRCode.toDataURL(url, {
      width: 200,
      margin: 2,
      color: {
        dark: '#000000',
        light: '#FFFFFF'
      }
    });
    return qrDataUrl;
  } catch (error) {
    console.error('QR generation error:', error);
    throw new Error('Failed to generate QR code');
  }
}